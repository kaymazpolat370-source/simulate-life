/* =====================================================
   LIFE SIMULATOR v2 — script.js
   Complete game engine
   ===================================================== */
"use strict";

/* ─────────────────────────────────────────────────────
   CONSTANTS
───────────────────────────────────────────────────── */
const SAVE_KEY = "lifesim_v1";
const MAX_ENERGY = 100;

const FORMATS = [
  { id:"pov",      icon:"👁️",  nameEn:"POV",        nameTr:"POV"      },
  { id:"vlog",     icon:"🎥",  nameEn:"Vlog",       nameTr:"Vlog"     },
  { id:"challenge",icon:"🏆",  nameEn:"Challenge",  nameTr:"Yarışma"  },
  { id:"prank",    icon:"😜",  nameEn:"Prank",      nameTr:"Şaka"     },
  { id:"liveqa",   icon:"📡",  nameEn:"Live Q&A",   nameTr:"Canlı S&C"},
  { id:"tutorial", icon:"📚",  nameEn:"Tutorial",   nameTr:"Eğitim"   },
  { id:"unboxing", icon:"📦",  nameEn:"Unboxing",   nameTr:"Kutu Açma"},
  { id:"reaction", icon:"😲",  nameEn:"Reaction",   nameTr:"Tepki"    },
  { id:"storytime",icon:"📖",  nameEn:"Storytime",  nameTr:"Hikaye"   },
  { id:"asmr",     icon:"🎙️",  nameEn:"ASMR",       nameTr:"ASMR"     }
];

const NICHES = [
  { id:"football",      icon:"⚽",  nameEn:"Football",       nameTr:"Futbol"       },
  { id:"comedy",        icon:"😂",  nameEn:"Comedy",         nameTr:"Komedi"       },
  { id:"gaming",        icon:"🎮",  nameEn:"Gaming",         nameTr:"Oyun"         },
  { id:"entrepreneurship",icon:"💼",nameEn:"Entrepreneur",   nameTr:"Girişim"      },
  { id:"technology",    icon:"💻",  nameEn:"Technology",     nameTr:"Teknoloji"    },
  { id:"streetinterview",icon:"🎤", nameEn:"Street Int.",    nameTr:"Sokak Röp."   },
  { id:"food",          icon:"🍔",  nameEn:"Food",           nameTr:"Yemek"        },
  { id:"fashion",       icon:"👗",  nameEn:"Fashion",        nameTr:"Moda"         },
  { id:"crypto",        icon:"₿",   nameEn:"Crypto",         nameTr:"Kripto"       },
  { id:"mystery",       icon:"🔮",  nameEn:"Mystery",        nameTr:"Gizem"        }
];

// Perfect format+niche combos give +150 base views
const SYNERGIES = [
  ["vlog","entrepreneurship"],
  ["challenge","gaming"],
  ["pov","football"],
  ["tutorial","technology"],
  ["asmr","food"],
  ["reaction","comedy"],
  ["unboxing","crypto"],
  ["liveqa","fashion"],
  ["prank","streetinterview"],
  ["storytime","mystery"]
];

const SHOP_ITEMS = [
  { id:"mic",      emoji:"🎤", cost:150,  multAdd:0.2, bpmNew:0.25,
    nameEn:"Lavalier Mic",     nameTr:"Yaka Mikrofonu",
    descEn:"+0.2x Multiplier · BPM → 0.25 TL",
    descTr:"+0.2x Çarpan · BPM → 0.25 TL" },
  { id:"light",    emoji:"💡", cost:350,  multAdd:0.5, bpmNew:0.50,
    nameEn:"Ring Light",       nameTr:"Işık",
    descEn:"+0.5x Multiplier · BPM → 0.50 TL",
    descTr:"+0.5x Çarpan · BPM → 0.50 TL" },
  { id:"greenscreen",emoji:"🟩",cost:800, multAdd:1.0, bpmNew:1.50,
    nameEn:"Green Screen",     nameTr:"Yeşil Ekran",
    descEn:"+1.0x Multiplier · BPM → 1.50 TL",
    descTr:"+1.0x Çarpan · BPM → 1.50 TL" },
  { id:"phone",    emoji:"📱", cost:2500, multAdd:2.5, bpmNew:2.50,
    nameEn:"New Smartphone",   nameTr:"Yeni Telefon",
    descEn:"+2.5x Multiplier · BPM → 2.50 TL",
    descTr:"+2.5x Çarpan · BPM → 2.50 TL" },
  { id:"camera",   emoji:"📷", cost:7500, multAdd:5.0, bpmNew:4.00,
    nameEn:"Studio Camera",    nameTr:"Pro Kamera",
    descEn:"+5.0x Multiplier · BPM → 4.00 TL",
    descTr:"+5.0x Çarpan · BPM → 4.00 TL" }
];

/* ─────────────────────────────────────────────────────
   I18N
───────────────────────────────────────────────────── */
const LANG = {
en: {
  /* Home */
  home_greeting: "Day {d} — Keep grinding!",
  hs_day: "Day", hs_flw: "Followers", hs_algo: "Algorithm",
  app_jobs: "Job Board", app_shop: "Shop", app_settings: "Settings",
  monetized_ribbon: "💰 Monetized! Earning ad revenue daily.",

  /* Status bar */
  sb_day: "Day {d}",

  /* Energy */
  energy_label: "Energy",

  /* Next Day */
  next_day_btn: "⏭  Next Day",

  /* Jobs */
  jobs_title: "Job Board",
  jobs_energy_lbl: "Energy",
  jobs_notice: "Work jobs to earn cash before you get monetized. Energy resets every day.",
  job_flyer: "Flyer Distribution",
  job_moto: "Moto-Delivery",
  job_energy_cost: "⚡ {e} Energy",
  job_reward: "+{c}",
  job_do: "Do Job",
  job_done: "Done!",
  job_no_energy: "Not enough energy! Rest up and try again tomorrow.",
  jobs_tip: "💡 Tip: At 10,000 followers you'll unlock ad revenue and won't need to work jobs anymore.",

  /* Shop */
  shop_title: "Setup Shop",
  shs_mult: "Equipment Multiplier",
  shs_bpm: "Ad Rate (BPM)",
  shop_buy: "Buy",
  shop_owned: "Owned ✓",
  shop_no_cash: "Not enough cash!",

  /* TokTik Setup */
  tt_su_heading: "Create Your Profile",
  tt_su_sub: "Pick a username that will make you famous. This is your identity on TokTik.",
  tt_su_label: "Your Username",
  tt_su_hint: "2–18 chars · Letters, numbers, underscores only",
  tt_register_btn: "Start My Journey",
  tt_err_empty: "Please enter a username.",
  tt_err_short: "Username must be at least 2 characters.",
  tt_err_invalid: "Only letters, numbers, and underscores allowed.",

  /* TokTik tabs */
  tab_stats: "Profile", tab_create: "Create", tab_board: "Rankings",

  /* TokTik stats panel */
  ttar_lbl: "Algorithm",
  trending_label: "🔥 Trending Today:",
  monetize_locked: "🔒 Monetization locked until 10,000 followers ({n} more needed)",
  monetize_unlocked: "💰 Monetized! Daily BPM: {b} TL/1K views",
  rank_label: "Global Rank",
  feed_hd: "Recent Posts",
  no_posts: "No posts yet — head to Create tab!",
  pending_has: "📹 Video queued for overnight processing: {f} + {n}",
  pending_none: "No video queued today. Go to Create and post one!",

  /* Create panel */
  trending_create_prefix: "🔥 Trending:",
  create_energy: "⚡ Creating a video costs 50 energy",
  fmt_hd: "Select Format",
  niche_hd: "Select Niche",
  synergy_match: "✨ Perfect synergy! +150 bonus views",
  trending_bonus: "🔥 Trending niche! 3× view multiplier!",
  create_preview_none: "Choose a format and niche",
  create_video_btn: "🎬 Queue Video (50 Energy)",
  create_done_msg: "✅ Video queued! Click 'Next Day' to process it.",
  create_already: "You already have a video queued for today.",
  create_no_energy: "Not enough energy! You need 50 energy.",

  /* Leaderboard */
  lb_title: "Global Rankings",
  lb_sub: "Outrank 100 creators to become #1!",
  lb_you: "★ You",

  /* Morning Report */
  mr_title: "☀️ Morning Report",
  mr_day: "End of Day {d}",
  mr_views: "Views Gained",
  mr_followers: "Followers Gained",
  mr_likes: "Likes Gained",
  mr_ad_rev: "Ad Revenue",
  mr_survival: "Survival Cost (Day {d})",
  mr_no_video: "0 (no video posted)",
  mr_sponsor_bonus: "🤝 Sponsor bonus: +200 TL ({n} days remaining)",
  mr_monetized_unlock: "🎉 You've reached 10,000 followers! Ad monetization is now UNLOCKED!",
  mr_comments_hd: "💬 Viewer Comments",
  mr_dismiss: "Start Day {d}  →",

  /* Comments - High tier (>1000 views) */
  comments_high: [
    ["@ViralKing99","That combo was INSANE, trending for a reason!"],
    ["@ContentQueen","Best creator I've followed this week 🔥🔥"],
    ["@AlgoWatcher","Algorithm is boosting this hard, keep going!"],
    ["@FanAccount88","Shared with everyone I know, absolute fire 🔥"],
    ["@GrowthHacker","This is textbook viral content. Respect."]
  ],
  /* Comments - Mid tier (200-1000 views) */
  comments_mid: [
    ["@NormalViewer","Pretty decent video, keep posting!"],
    ["@CasualScroller","Not bad, I'll check your next one."],
    ["@HonestFeedback","Good effort! Quality could be a bit higher."],
    ["@ContentBro","Solid niche choice, build on this."],
    ["@AlgoBot3000","Views are steady. Consistency pays off."]
  ],
  /* Comments - Low tier (<200 views) */
  comments_low: [
    ["@BluntCritic","Cringe content, fix your mic quality!"],
    ["@RealTalk77","Not hitting the trending topics at all bro."],
    ["@AlgoAnalyst","Algorithm is not picking this up. Try trending niches."],
    ["@SleepyViewer","Fell asleep halfway through... 😴"],
    ["@HarshButFair","The combo isn't working. Try a synergy pair."]
  ],

  /* Sponsor offers */
  sp50k_title: "👕 Sponsor Offer!",
  sp50k_body: "A local apparel brand wants to work with you! Accept for +200 TL bonus per video for the next 3 days.",
  sp50k_accept: "Accept Deal",
  sp50k_decline: "Decline",

  sp500k_title: "🏢 Tech Giant Offer!",
  sp500k_body: "A major tech company wants a promotional video! Record it (costs 30 energy) for an instant +5,000 TL payday.",
  sp500k_accept: "Record Promo (30 ⚡)",
  sp500k_decline: "Decline",
  sp500k_no_energy: "Not enough energy to record the promo (need 30).",

  /* Settings */
  settings_title: "Settings",
  stg_hd_audio: "Audio",
  stg_sound_lbl: "Sound Effects",
  stg_hd_lang: "Language",
  stg_lang_lbl: "Language",
  stg_hd_privacy: "Data Safety & Privacy",
  btn_show_privacy: "View Privacy Policy",
  stg_hd_data: "Game Data",
  btn_save: "Save Game",
  btn_delete: "Delete All My Data & Reset",

  /* Privacy Modal */
  pm_title: "Data Safety & Privacy",
  pm_sub: "Life Simulator — Full Disclosure",
  pm_ds_hd: "Data Safety",
  pm_ds_body: "This game operates 100% offline. We do NOT collect, share, or transmit any user data, personal info, or device identifiers to external servers. All data is saved locally on your own device using localStorage.",
  pm_coppa_hd: "Children's Privacy (COPPA)",
  pm_coppa_body: "Fully compliant with COPPA. No behavioral tracking or analytics utilized. No advertising SDKs or third-party trackers are embedded in this application.",
  pm_local_hd: "Local Data Storage",
  pm_local_body: "Your game progress is stored exclusively in your browser's localStorage under the key 'lifesim_v1'. This data never leaves your device.",
  pm_close: "Close",

  /* Delete confirmation */
  delete_confirm: "Are you absolutely sure? This will permanently delete all your progress and cannot be undone.",
  delete_confirm2: "Last chance — delete everything?",

  /* Toast messages */
  toast_saved: "Game saved! ✓",
  toast_job_flyer: "+60 TL earned!",
  toast_job_moto: "+120 TL earned!",
  toast_shop_bought: "Purchased! Multiplier now {m}x",
  toast_sponsor_accepted: "Sponsorship deal accepted!",
  toast_sponsor_recorded: "+5,000 TL earned from promo!",
  toast_lang_changed: "Language changed to English",
},

tr: {
  /* Home */
  home_greeting: "{d}. Gün — Devam et!",
  hs_day: "Gün", hs_flw: "Takipçi", hs_algo: "Algoritma",
  app_jobs: "İş İlanları", app_shop: "Mağaza", app_settings: "Ayarlar",
  monetized_ribbon: "💰 Monetize edildi! Her gün reklam geliri kazanıyorsun.",

  /* Status bar */
  sb_day: "{d}. Gün",

  /* Energy */
  energy_label: "Enerji",

  /* Next Day */
  next_day_btn: "⏭  Günü Bitir",

  /* Jobs */
  jobs_title: "İş İlanları",
  jobs_energy_lbl: "Enerji",
  jobs_notice: "Para kazanmak için iş yap. Monetize olana kadar hayatta kalmak zorundasın.",
  job_flyer: "Broşür Dağıtımı",
  job_moto: "Moto-Kurye",
  job_energy_cost: "⚡ {e} Enerji",
  job_reward: "+{c}",
  job_do: "Yap",
  job_done: "Tamam!",
  job_no_energy: "Yetersiz Enerji! Yarın tekrar dene.",
  jobs_tip: "💡 İpucu: 10.000 takipçide reklam geliri açılır ve artık iş yapman gerekmez.",

  /* Shop */
  shop_title: "Ekipman Mağazası",
  shs_mult: "Ekipman Çarpanı",
  shs_bpm: "Reklam Oranı (BPM)",
  shop_buy: "Satın Al",
  shop_owned: "Sahip ✓",
  shop_no_cash: "Yetersiz para!",

  /* TokTik Setup */
  tt_su_heading: "Profilini Oluştur",
  tt_su_sub: "Seni ünlü yapacak bir kullanıcı adı seç. Bu TokTik'teki kimliğin olacak.",
  tt_su_label: "Kullanıcı Adın",
  tt_su_hint: "2–18 karakter · Harf, rakam ve alt çizgi kullanılabilir",
  tt_register_btn: "Yolculuğumu Başlat",
  tt_err_empty: "Lütfen bir kullanıcı adı girin.",
  tt_err_short: "Kullanıcı adı en az 2 karakter olmalıdır.",
  tt_err_invalid: "Sadece harf, rakam ve alt çizgi kullanılabilir.",

  /* TokTik tabs */
  tab_stats: "Profil", tab_create: "Oluştur", tab_board: "Sıralama",

  /* TokTik stats panel */
  ttar_lbl: "Algoritma",
  trending_label: "🔥 Bugünün Trendleri:",
  monetize_locked: "🔒 Monetizasyon {n} takipçi sonra açılacak (10.000 hedef)",
  monetize_unlocked: "💰 Monetize edildi! BPM: {b} TL/1K görüntüleme",
  rank_label: "Global Sıra",
  feed_hd: "Son Paylaşımlar",
  no_posts: "Henüz paylaşım yok — Oluştur sekmesine git!",
  pending_has: "📹 Bu gece işlenecek video: {f} + {n}",
  pending_none: "Bugün video yok. Oluştur sekmesine git!",

  /* Create panel */
  trending_create_prefix: "🔥 Trend:",
  create_energy: "⚡ Video oluşturmak 50 enerji harcar",
  fmt_hd: "Format Seç",
  niche_hd: "Niş Seç",
  synergy_match: "✨ Mükemmel uyum! +150 bonus görüntüleme",
  trending_bonus: "🔥 Trend niş! 3× görüntüleme çarpanı!",
  create_preview_none: "Format ve niş seç",
  create_video_btn: "🎬 Video Kuyruğa Al (50 Enerji)",
  create_done_msg: "✅ Video kuyruğa alındı! 'Günü Bitir'e bas.",
  create_already: "Bugün zaten bir videon kuyruğa alınmış.",
  create_no_energy: "Yetersiz enerji! 50 enerji gerekiyor.",

  /* Leaderboard */
  lb_title: "Global Sıralama",
  lb_sub: "100 içerik üreticisini geçerek 1 numaraya ulaş!",
  lb_you: "★ Sen",

  /* Morning Report */
  mr_title: "☀️ Sabah Raporu",
  mr_day: "{d}. Gün Sonu",
  mr_views: "Kazanılan Görüntüleme",
  mr_followers: "Kazanılan Takipçi",
  mr_likes: "Kazanılan Beğeni",
  mr_ad_rev: "Reklam Geliri",
  mr_survival: "Geçim Masrafı ({d}. Gün)",
  mr_no_video: "0 (video paylaşılmadı)",
  mr_sponsor_bonus: "🤝 Sponsor bonusu: +200 TL ({n} gün kaldı)",
  mr_monetized_unlock: "🎉 10.000 takipçiye ulaştın! Reklam monetizasyonu AÇILDI!",
  mr_comments_hd: "💬 İzleyici Yorumları",
  mr_dismiss: "{d}. Güne Başla  →",

  /* Comments - High */
  comments_high: [
    ["@ViralKral99","Bu kombinasyon EFSANE, trend olması boşuna değil!"],
    ["@İçerikKraliçe","Bu hafta takip ettiğim en iyi içerik üretici 🔥🔥"],
    ["@AlgoTakipçi","Algoritma bunu çok yüksek itiyor, devam et!"],
    ["@FanHesap88","Herkese gönderdim, kesinlikle ateş 🔥"],
    ["@BüyümeUzmanı","Ders kitabı gibi viral içerik. Saygılar."]
  ],
  /* Comments - Mid */
  comments_mid: [
    ["@NormalİzleyiciTR","Fena değil, paylaşmaya devam et!"],
    ["@RasgeleKaydır","Kötü değil, bir sonrakine bakacağım."],
    ["@DürüstGeribildirim","İyi çaba! Kalite biraz daha iyi olabilir."],
    ["@İçerikArkadaşı","İyi niş seçimi, bu temelde devam et."],
    ["@AlgoBot3000","Görüntülemeler sabit. Tutarlılık önemli."]
  ],
  /* Comments - Low */
  comments_low: [
    ["@DüzSözleyen","Utanç verici içerik, mikrofonunu düzelt!"],
    ["@GerçekKonuşma77","Hiç trend konulara girmiyor kardeşim."],
    ["@AlgoAnalisti","Algoritma bunu almıyor. Trend nişleri dene."],
    ["@UykuluİzleyiciTR","Yarısında uyuyakaldım... 😴"],
    ["@SertyAmaAdil","Bu kombinasyon tutmuyor. Sinerji dene."]
  ],

  /* Sponsor offers */
  sp50k_title: "👕 Sponsor Teklifi!",
  sp50k_body: "Yerel bir giyim markası seninle çalışmak istiyor! Sonraki 3 gün boyunca her video için +200 TL bonus kazan.",
  sp50k_accept: "Anlaşmayı Kabul Et",
  sp50k_decline: "Reddet",

  sp500k_title: "🏢 Teknoloji Devi Teklifi!",
  sp500k_body: "Büyük bir teknoloji şirketi tanıtım videosu istiyor! Çek (30 enerji) ve anında +5.000 TL kazan.",
  sp500k_accept: "Promo Çek (30 ⚡)",
  sp500k_decline: "Reddet",
  sp500k_no_energy: "Promo için yeterli enerji yok (30 gerekiyor).",

  /* Settings */
  settings_title: "Ayarlar",
  stg_hd_audio: "Ses",
  stg_sound_lbl: "Ses Efektleri",
  stg_hd_lang: "Dil",
  stg_lang_lbl: "Dil",
  stg_hd_privacy: "Veri Güvenliği ve Gizlilik",
  btn_show_privacy: "Gizlilik Politikasını Görüntüle",
  stg_hd_data: "Oyun Verisi",
  btn_save: "Oyunu Kaydet",
  btn_delete: "Tüm Verilerimi Sil ve Sıfırla",

  /* Privacy Modal */
  pm_title: "Veri Güvenliği ve Gizlilik",
  pm_sub: "Life Simulator — Tam Açıklama",
  pm_ds_hd: "Veri Güvenliği",
  pm_ds_body: "Bu oyun %100 çevrimdışı çalışır. Kişisel bilgilerinizi veya cihaz kimliklerinizi asla toplamaz, paylaşmaz ve harici sunuculara aktarmayız. Tüm veriler cihazınızda localStorage aracılığıyla yerel olarak saklanır.",
  pm_coppa_hd: "Çocuk Gizliliği (COPPA)",
  pm_coppa_body: "COPPA standartlarına tamamen uygundur. Hiçbir davranışsal takip veya analiz mekanizması barındırmaz. Üçüncü taraf reklam SDK'ları veya izleyiciler yoktur.",
  pm_local_hd: "Yerel Veri Depolama",
  pm_local_body: "Oyun ilerlemeniz yalnızca tarayıcınızın localStorage'ında 'lifesim_v1' anahtarı altında saklanır. Bu veriler cihazınızı asla terk etmez.",
  pm_close: "Kapat",

  /* Delete confirmation */
  delete_confirm: "Emin misin? Tüm ilerleme kalıcı olarak silinecek, geri alınamaz.",
  delete_confirm2: "Son şans — her şeyi sil?",

  /* Toast messages */
  toast_saved: "Oyun kaydedildi! ✓",
  toast_job_flyer: "+60 TL kazandın!",
  toast_job_moto: "+120 TL kazandın!",
  toast_shop_bought: "Satın alındı! Çarpan artık {m}x",
  toast_sponsor_accepted: "Sponsorluk anlaşması kabul edildi!",
  toast_sponsor_recorded: "+5.000 TL promosyon geliri!",
  toast_lang_changed: "Dil Türkçe'ye değiştirildi",
}
};

/* ─────────────────────────────────────────────────────
   AUDIO ENGINE
───────────────────────────────────────────────────── */
let _audioCtx = null;
function getCtx(){
  if(!_audioCtx){try{_audioCtx=new(window.AudioContext||window.webkitAudioContext)();}catch(e){}}
  return _audioCtx;
}
function beep(freq,dur,type,vol){
  if(!S.sound)return;
  const ctx=getCtx();if(!ctx)return;
  try{
    const o=ctx.createOscillator(),g=ctx.createGain();
    o.connect(g);g.connect(ctx.destination);
    o.type=type||'sine';o.frequency.value=freq;
    g.gain.setValueAtTime(vol||0.1,ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001,ctx.currentTime+dur);
    o.start();o.stop(ctx.currentTime+dur);
  }catch(e){}
}
const SFX={
  tap:()=>beep(880,.05,'sine',.07),
  back:()=>beep(440,.08,'sine',.07),
  success:()=>{beep(523,.1,'sine',.1);setTimeout(()=>beep(659,.1,'sine',.1),100);setTimeout(()=>beep(784,.14,'sine',.1),200)},
  coins:()=>{[784,1047].forEach((f,i)=>setTimeout(()=>beep(f,.1,'triangle',.1),i*80))},
  error:()=>beep(220,.18,'sawtooth',.05),
  nextday:()=>{[440,523,659,784].forEach((f,i)=>setTimeout(()=>beep(f,.1,'sine',.09),i*60))},
  viral:()=>{[523,659,784,1047,1319].forEach((f,i)=>setTimeout(()=>beep(f,.1,'sine',.1),i*70))},
  buy:()=>{beep(660,.08,'triangle',.09);setTimeout(()=>beep(880,.12,'triangle',.1),90)},
};

/* ─────────────────────────────────────────────────────
   STATE
───────────────────────────────────────────────────── */
const DEF_STATE = ()=>({
  language:"en",
  sound:true,
  day:1,
  energy:MAX_ENERGY,
  cash:50,
  followers:0,
  likes:0,
  algorithmScore:1.0,
  isMonetized:false,
  activeSponsor:null,        // 'local' | 'tech' | null
  sponsorDaysLeft:0,
  currentEquipmentMultiplier:1.0,
  currentBpm:0.10,
  boughtItems:[],
  toktik:{
    registered:false,
    username:"",
    videos:0,
    pendingVideo:null,       // {format, niche} or null
    feed:[]
  },
  aiInfluencers:[],
  trendingNiches:[],
  sponsor50kShown:false,
  sponsor500kShown:false,
  lastReport:null,
  totalDays:0
});

let S = DEF_STATE();

function saveState(){
  try{localStorage.setItem(SAVE_KEY,JSON.stringify(S));}catch(e){}
}
function loadState(){
  try{
    const r=localStorage.getItem(SAVE_KEY);
    if(!r)return false;
    const p=JSON.parse(r);
    S=Object.assign(DEF_STATE(),p);
    S.toktik=Object.assign(DEF_STATE().toktik,p.toktik||{});
    return true;
  }catch(e){return false;}
}

/* ─────────────────────────────────────────────────────
   HELPERS
───────────────────────────────────────────────────── */
function t(key,vars){
  const d=LANG[S.language]||LANG.en;
  let s=d[key];
  if(s===undefined)s=(LANG.en[key])||key;
  if(vars&&typeof s==='string'){
    for(const[k,v]of Object.entries(vars))s=s.replace(new RegExp(`\\{${k}\\}`,'g'),v);
  }
  return s!==undefined?s:key;
}
function fmt(n){
  if(n>=1e9)return(n/1e9).toFixed(1)+'B';
  if(n>=1e6)return(n/1e6).toFixed(1)+'M';
  if(n>=1e3)return(n/1e3).toFixed(1)+'K';
  return String(Math.floor(n));
}
function cash(n){
  const v=Math.round(n);
  return S.language==='tr'?v+' TL':'$'+v;
}
function el(id){return document.getElementById(id);}
function setText(id,val){const e=el(id);if(e)e.textContent=val;}
function on(id,ev,fn){const e=el(id);if(e)e.addEventListener(ev,fn);}

/* ─────────────────────────────────────────────────────
   TOAST & FLOAT TEXT
───────────────────────────────────────────────────── */
let _toastTimer=null;
function showToast(msg){
  const e=el('toast');if(!e)return;
  e.textContent=msg;e.classList.remove('hidden');
  if(_toastTimer)clearTimeout(_toastTimer);
  _toastTimer=setTimeout(()=>e.classList.add('hidden'),2600);
}
function floatReward(msg,yPos){
  const e=el('float-reward');if(!e)return;
  e.textContent=msg;
  e.style.bottom=(yPos||100)+'px';
  e.classList.remove('hidden');
  setTimeout(()=>e.classList.add('hidden'),900);
}

/* ─────────────────────────────────────────────────────
   STATUS BAR
───────────────────────────────────────────────────── */
function updateStatusBar(){
  // Simulated clock
  const h=(9+((S.day-1)*3))%24, m=((S.day*17)%60);
  setText('sb-time',String(h).padStart(2,'0')+':'+String(m).padStart(2,'0'));
  setText('sb-day-lbl',t('sb_day',{d:S.day}));
  setText('sb-cash',cash(S.cash));

  // Battery
  const batt=Math.max(12,100-((S.day-1)*0.7)%88);
  const fill=el('batt-fill');
  if(fill){
    fill.style.width=batt+'%';
    fill.style.background=batt>30?'var(--green)':batt>15?'var(--yellow)':'var(--red)';
  }
  setText('batt-pct',Math.round(batt)+'%');
}

/* ─────────────────────────────────────────────────────
   ENERGY BAR
───────────────────────────────────────────────────── */
function updateEnergyBar(){
  const pct=(S.energy/MAX_ENERGY)*100;
  const fill=el('enr-fill');
  if(fill){
    fill.style.width=pct+'%';
    fill.style.background=pct>50?'linear-gradient(90deg,var(--yellow),var(--orange))':
                           pct>25?'linear-gradient(90deg,var(--orange),var(--red))':
                           'var(--red)';
  }
  setText('enr-val',S.energy+'/'+MAX_ENERGY);
}

/* ─────────────────────────────────────────────────────
   SCREEN NAVIGATION
───────────────────────────────────────────────────── */
let currentScreen='home';
function showScreen(id){
  document.querySelectorAll('.screen').forEach(s=>s.classList.remove('active'));
  const t=el('screen-'+id);
  if(t){t.classList.add('active');currentScreen=id;}
  // Trigger renders
  if(id==='jobs')renderJobs();
  if(id==='shop')renderShop();
  if(id==='settings')renderSettings();
  if(id==='toktik')renderTokTik();
  if(id==='home')renderHome();
}

/* ─────────────────────────────────────────────────────
   HOME SCREEN
───────────────────────────────────────────────────── */
function renderHome(){
  setText('home-greeting',t('home_greeting',{d:S.day}));
  setText('hs-day-lbl',t('hs_day'));
  setText('hs-flw-lbl',t('hs_flw'));
  setText('hs-algo-lbl',t('hs_algo'));
  setText('hs-day-val',String(S.day));
  setText('hs-flw-val',fmt(S.followers));
  setText('hs-algo-val',S.algorithmScore.toFixed(2)+'x');
  setText('app-lbl-jobs',t('app_jobs'));
  setText('app-lbl-shop',t('app_shop'));
  setText('app-lbl-settings',t('app_settings'));
  setText('btn-next-day',t('next_day_btn'));
  const rib=el('home-monetized-ribbon');
  if(rib){
    if(S.isMonetized){rib.classList.remove('hidden');rib.textContent=t('monetized_ribbon');}
    else rib.classList.add('hidden');
  }
}

/* ─────────────────────────────────────────────────────
   JOB BOARD
───────────────────────────────────────────────────── */
function renderJobs(){
  setText('jobs-title',t('jobs_title'));
  setText('jeb-lbl',t('energy_label'));
  setText('jeb-val',S.energy+'/'+MAX_ENERGY);
  const pct=(S.energy/MAX_ENERGY)*100;
  const jf=el('jeb-fill');if(jf)jf.style.width=pct+'%';
  setText('jobs-notice',t('jobs_notice'));
  setText('job-flyer-name',t('job_flyer'));
  setText('job-moto-name',t('job_moto'));
  setText('job-flyer-energy',t('job_energy_cost',{e:40}));
  setText('job-moto-energy',t('job_energy_cost',{e:60}));
  setText('job-flyer-reward',t('job_reward',{c:'60 '+(S.language==='tr'?'TL':'$')}));
  setText('job-moto-reward',t('job_reward',{c:'120 '+(S.language==='tr'?'TL':'$')}));
  const bf=el('btn-flyer'),bm=el('btn-moto');
  if(bf){bf.textContent=t('job_do');bf.disabled=S.energy<40;}
  if(bm){bm.textContent=t('job_do');bm.disabled=S.energy<60;}
  setText('jobs-tip',t('jobs_tip'));
}

function doJob(type){
  const cost=type==='flyer'?40:60;
  const reward=type==='flyer'?60:120;
  if(S.energy<cost){SFX.error();showToast(t('job_no_energy'));return;}
  S.energy-=cost;
  S.cash+=reward;
  SFX.coins();
  const msg=type==='flyer'?t('toast_job_flyer'):t('toast_job_moto');
  showToast(msg);
  floatReward('+'+(S.language==='tr'?reward+' TL':'$'+reward),140);
  saveState();
  updateStatusBar();
  updateEnergyBar();
  renderJobs();
}

/* ─────────────────────────────────────────────────────
   SHOP
───────────────────────────────────────────────────── */
function renderShop(){
  setText('shop-title',t('shop_title'));
  setText('shs-mult-lbl',t('shs_mult'));
  setText('shs-bpm-lbl',t('shs_bpm'));
  setText('shs-mult-val',S.currentEquipmentMultiplier.toFixed(1)+'x');
  setText('shs-bpm-val',S.currentBpm.toFixed(2)+' TL');
  const list=el('shop-items-list');
  if(!list)return;
  list.innerHTML=SHOP_ITEMS.map(item=>{
    const owned=S.boughtItems.includes(item.id);
    const canAfford=S.cash>=item.cost;
    const name=S.language==='tr'?item.nameTr:item.nameEn;
    const desc=S.language==='tr'?item.descTr:item.descEn;
    const btnHtml=owned
      ?`<div class="shop-bought-badge">${t('shop_owned')}</div>`
      :`<button class="shop-buy-btn" data-shopid="${item.id}" ${canAfford?'':'disabled'}>${t('shop_buy')}<br><span style="font-size:10px;font-weight:500">${item.cost} TL</span></button>`;
    return `
      <div class="shop-item ${owned?'purchased':''}">
        <div class="shop-item-icon">${item.emoji}</div>
        <div class="shop-item-info">
          <div class="shop-item-name">${name}</div>
          <div class="shop-item-details">${desc}</div>
        </div>
        ${btnHtml}
      </div>`;
  }).join('');
  list.querySelectorAll('.shop-buy-btn').forEach(btn=>{
    btn.addEventListener('click',()=>buyShopItem(btn.dataset.shopid));
  });
}

function buyShopItem(id){
  const item=SHOP_ITEMS.find(x=>x.id===id);
  if(!item)return;
  if(S.boughtItems.includes(id)){showToast(t('shop_owned'));return;}
  if(S.cash<item.cost){SFX.error();showToast(t('shop_no_cash'));return;}
  S.cash-=item.cost;
  S.boughtItems.push(id);
  S.currentEquipmentMultiplier=parseFloat((S.currentEquipmentMultiplier+item.multAdd).toFixed(2));
  S.currentBpm=item.bpmNew;
  SFX.buy();
  showToast(t('toast_shop_bought',{m:S.currentEquipmentMultiplier.toFixed(1)}));
  saveState();
  updateStatusBar();
  renderShop();
}

/* ─────────────────────────────────────────────────────
   AI INFLUENCERS
───────────────────────────────────────────────────── */
const AI_NAMES=[
  "AlphaGamer","CryptoKing","FashionQueen","TechWizard","ViralDancer",
  "MysticVlogger","ComedyBoss","FoodieKing","FootballFreak","NightOwlTV",
  "CryptoWave","StreetLegend","GamingPro","FashionForward","TechByte",
  "VlogMaster","PrankStar","ASMRDream","TutorialGod","ReactionKing",
  "Entrepreneur99","MysteryBox","FoodNetwork","FashionIcon","CoinHunter",
  "SoccerStar","JokeMaster","PixelPro","TrendSetter","ContentKing",
  "NightVlogger","CryptoQueen","GamingLegend","StyleGuru","CodeWizard",
  "StoryTeller","ShockFactor","SoundscapeX","HowToGuy","GasReactor",
  "StartupBoss","ShadowMystery","RecipeReel","StreetFashion","BitcoinBro",
  "GoalMachine","LaughFactory","ConsoleChamp","RunwayReady","DevTalks",
  "JourneyVlog","HahaHero","QALive","BoxOpener","ReviewRush",
  "NarrationNinja","WhisperWorld","LearnItAll","ComboKing","SportsCraze",
  "TechTrendz","VibzMaker","FoodFiesta","FitFashion","BlockchainBabe",
  "StadiumSound","PunchlineKing","GamerzOnly","CatWalkPro","ByteSize",
  "LifeInStories","GiggleFest","AudibleAura","ExplainEverything","ClipReactor",
  "FounderFuel","EnigmaEdge","TasteTrail","UrbanStyle","SatoshiSage",
  "KickoffKing","ComedyCentral","LevelUpTV","GlamourGrid","CloudCoder",
  "EpisodeArch","PrankBros","LiveTalkz","UnwrapIt","OpinionOrb",
  "TaleSpinner","ZenSounds","SkillCraft","WatchMe","MemeReact",
  "HustleHero","VaultMystery","CrispBite","FitFlex","NFTNerd",
  "FieldVision","JestJockey","ControllerPro","VogueVault","HackStream"
];
const AI_COLORS=['#1ee8f4','#f01ca0','#1fd88a','#f0c844','#9050f8','#f07020','#20a0f0','#e040e0'];

function generateAI(){
  const arr=[];
  const used=new Set();
  for(let i=0;i<100;i++){
    let name;let tries=0;
    do{name='@'+AI_NAMES[i%AI_NAMES.length]+(i>=AI_NAMES.length?Math.floor(i/AI_NAMES.length):'');tries++;}
    while(used.has(name)&&tries<5);
    used.add(name);
    const r=Math.random();
    let f;
    if(r<0.3)f=500+Math.floor(Math.random()*4500);
    else if(r<0.55)f=5000+Math.floor(Math.random()*45000);
    else if(r<0.75)f=50000+Math.floor(Math.random()*150000);
    else if(r<0.9)f=200000+Math.floor(Math.random()*300000);
    else f=500000+Math.floor(Math.random()*500000);
    arr.push({name,followers:f,color:AI_COLORS[i%AI_COLORS.length]});
  }
  arr.sort((a,b)=>b.followers-a.followers);
  return arr;
}

function tickAI(){
  S.aiInfluencers.forEach(ai=>{
    ai.followers=Math.floor(ai.followers*(1+0.005+Math.random()*0.015));
  });
  S.aiInfluencers.sort((a,b)=>b.followers-a.followers);
}

function getPlayerRank(){
  if(!S.toktik.registered)return 101;
  return S.aiInfluencers.filter(a=>a.followers>S.followers).length+1;
}

/* ─────────────────────────────────────────────────────
   TRENDING NICHES
───────────────────────────────────────────────────── */
function pickTrending(){
  const ids=NICHES.map(n=>n.id);
  const a=Math.floor(Math.random()*ids.length);
  let b;do{b=Math.floor(Math.random()*ids.length);}while(b===a);
  return[ids[a],ids[b]];
}
function getTrendingNames(){
  return S.trendingNiches.map(id=>{
    const n=NICHES.find(x=>x.id===id);
    return n?(S.language==='tr'?n.nameTr:n.nameEn):'?';
  }).join(' · ');
}

/* ─────────────────────────────────────────────────────
   TOKTIK RENDER
───────────────────────────────────────────────────── */
let selFormat=null, selNiche=null;

function renderTokTik(){
  if(!S.toktik.registered){
    el('tt-setup').classList.remove('hidden');
    el('tt-main').classList.add('hidden');
    renderSetup();
  } else {
    el('tt-setup').classList.add('hidden');
    el('tt-main').classList.remove('hidden');
    setText('ttab-stats',t('tab_stats'));
    setText('ttab-create',t('tab_create'));
    setText('ttab-board',t('tab_board'));
    setText('tt-day-lbl',t('sb_day',{d:S.day}));
    // render active panel
    const active=document.querySelector('.tt-panel.active');
    if(active){
      if(active.id==='ttp-stats')renderStatsPanel();
      if(active.id==='ttp-create')renderCreatePanel();
      if(active.id==='ttp-board')renderLeaderboard();
    } else renderStatsPanel();
  }
}

function renderSetup(){
  setText('tt-su-heading',t('tt_su_heading'));
  setText('tt-su-sub',t('tt_su_sub'));
  setText('tt-su-label',t('tt_su_label'));
  const inp=el('tt-username-inp');
  if(inp)inp.placeholder='@'+(S.language==='tr'?'kullanici_adin':'your_username');
  setText('tt-su-hint',t('tt_su_hint'));
  setText('tt-register-btn',t('tt_register_btn'));
}

function registerTokTik(){
  const inp=el('tt-username-inp');
  if(!inp)return;
  const v=inp.value.trim();
  if(!v){SFX.error();showToast(t('tt_err_empty'));return;}
  if(v.length<2){SFX.error();showToast(t('tt_err_short'));return;}
  if(!/^[a-zA-Z0-9_ğüşöçıİĞÜŞÖÇ]+$/.test(v)){SFX.error();showToast(t('tt_err_invalid'));return;}
  S.toktik.username=v;
  S.toktik.registered=true;
  if(!S.aiInfluencers.length)S.aiInfluencers=generateAI();
  if(!S.trendingNiches.length)S.trendingNiches=pickTrending();
  SFX.success();
  saveState();
  renderTokTik();
}

/* Stats panel */
function renderStatsPanel(){
  const tt=S.toktik;
  const letter=tt.username?tt.username[0].toUpperCase():'?';
  setText('tt-ava-letter',letter);
  setText('tt-uname',tt.username);
  setText('tt-ctr-f',fmt(S.followers));
  setText('tt-ctr-l',fmt(S.likes));
  setText('tt-ctr-v',String(tt.videos));
  setText('tt-clbl-f',t('tab_stats').includes('Profil')?'Takipçi':'Followers');
  // Use i18n direct
  const fl=LANG[S.language];
  const clblF=el('tt-clbl-f');if(clblF)clblF.textContent=S.language==='tr'?'Takipçi':'Followers';
  const clblL=el('tt-clbl-l');if(clblL)clblL.textContent=S.language==='tr'?'Beğeni':'Likes';
  const clblV=el('tt-clbl-v');if(clblV)clblV.textContent=S.language==='tr'?'Video':'Videos';

  // Algorithm score bar
  setText('ttar-lbl',t('ttar_lbl'));
  const barPct=((S.algorithmScore-0.5)/2.5)*100;
  const bar=el('ttar-bar');if(bar)bar.style.width=Math.min(100,barPct)+'%';
  setText('ttar-val',S.algorithmScore.toFixed(2)+'x');

  // Trending
  const trendText=t('trending_label')+' '+getTrendingNames();
  setText('ttrend-text',trendText);

  // Monetize status
  const monRow=el('tt-monetize-row');
  if(monRow){
    if(S.isMonetized){
      monRow.className='tt-monetize-row unlocked';
      monRow.textContent=t('monetize_unlocked',{b:S.currentBpm.toFixed(2)});
    } else {
      monRow.className='tt-monetize-row locked';
      const needed=Math.max(0,10000-S.followers);
      monRow.textContent=t('monetize_locked',{n:fmt(needed)});
    }
  }

  // Rank pill
  setText('ttrp-lbl',t('rank_label')+':');
  setText('ttrp-val','#'+getPlayerRank());

  // Pending notice
  const pn=el('tt-pending-notice');
  if(pn){
    if(S.toktik.pendingVideo){
      pn.className='tt-pending-notice has-video';
      const fmt2=FORMATS.find(f=>f.id===S.toktik.pendingVideo.format);
      const niche=NICHES.find(n=>n.id===S.toktik.pendingVideo.niche);
      const fname=fmt2?(S.language==='tr'?fmt2.nameTr:fmt2.nameEn):'?';
      const nname=niche?(S.language==='tr'?niche.nameTr:niche.nameEn):'?';
      pn.textContent=t('pending_has',{f:fname,n:nname});
    } else {
      pn.className='tt-pending-notice no-video';
      pn.textContent=t('pending_none');
    }
  }

  // Feed
  setText('tt-feed-hd',t('feed_hd'));
  renderFeed();
}

function renderFeed(){
  const feedEl=el('tt-feed');
  if(!feedEl)return;
  const feed=S.toktik.feed||[];
  if(!feed.length){
    feedEl.innerHTML=`<div style="text-align:center;color:var(--txt3);padding:16px;font-size:12px;">${t('no_posts')}</div>`;
    return;
  }
  feedEl.innerHTML=feed.slice(0,6).map(e=>{
    const fmt2=FORMATS.find(f=>f.id===e.format);
    const niche=NICHES.find(n=>n.id===e.niche);
    const fn=fmt2?(S.language==='tr'?fmt2.nameTr:fmt2.nameEn):'?';
    const nn=niche?(S.language==='tr'?niche.nameTr:niche.nameEn):'?';
    const cls=e.isViral?'trending':e.hasSynergy?'synergy':'';
    return`<div class="feed-entry">
      <div class="fe-icon">${fmt2?fmt2.icon:'🎬'}</div>
      <div class="fe-info">
        <div class="fe-title">${fn} + ${nn}</div>
        <div class="fe-sub">${S.language==='tr'?e.day+'. Gün':'Day '+e.day}</div>
      </div>
      <div class="fe-stat ${cls}">+${fmt(e.followers)}</div>
    </div>`;
  }).join('');
}

/* Create panel */
function renderCreatePanel(){
  // Trending hint
  const tt2=el('tt-trending-box-create');
  if(tt2){
    const tText=t('trending_create_prefix')+' '+getTrendingNames();
    setText('ttrend-text-create',tText);
  }

  // Energy notice
  setText('create-energy-notice',t('create_energy'));

  // Format grid
  setText('fmt-pick-hd',t('fmt_hd'));
  const fg=el('fmt-grid');
  if(fg){
    fg.innerHTML=FORMATS.map(f=>{
      const name=S.language==='tr'?f.nameTr:f.nameEn;
      return`<button class="fmt-btn${selFormat===f.id?' sel':''}" data-fid="${f.id}">
        <span class="fmt-icon">${f.icon}</span>
        <span class="fmt-name">${name}</span>
      </button>`;
    }).join('');
    fg.querySelectorAll('.fmt-btn').forEach(b=>b.addEventListener('click',()=>{
      selFormat=b.dataset.fid;SFX.tap();renderCreatePanel();
    }));
  }

  // Niche grid
  setText('niche-pick-hd',t('niche_hd'));
  const ng=el('niche-grid');
  if(ng){
    ng.innerHTML=NICHES.map(n=>{
      const name=S.language==='tr'?n.nameTr:n.nameEn;
      const isTrending=S.trendingNiches.includes(n.id);
      return`<button class="niche-btn${selNiche===n.id?' sel':''}${isTrending?' trending-niche':''}" data-nid="${n.id}">
        <span class="niche-icon">${n.icon}</span>
        <span class="niche-name">${name}${isTrending?' 🔥':''}</span>
      </button>`;
    }).join('');
    ng.querySelectorAll('.niche-btn').forEach(b=>b.addEventListener('click',()=>{
      selNiche=b.dataset.nid;SFX.tap();renderCreatePanel();
    }));
  }

  // Synergy / trending hint
  const sh=el('create-synergy-hint');
  if(sh){
    if(selFormat&&selNiche){
      const isTrendingNiche=S.trendingNiches.includes(selNiche);
      const isSynergy=SYNERGIES.some(s=>s[0]===selFormat&&s[1]===selNiche);
      sh.className='create-synergy-hint';
      if(isTrendingNiche){sh.classList.add('trending');sh.textContent=t('trending_bonus');}
      else if(isSynergy){sh.classList.add('match');sh.textContent=t('synergy_match');}
    } else {sh.className='create-synergy-hint';}
  }

  // Preview
  const fmt2=FORMATS.find(f=>f.id===selFormat);
  const niche=NICHES.find(n=>n.id===selNiche);
  const icon=fmt2?fmt2.icon:'🎬';
  const label=(fmt2?(S.language==='tr'?fmt2.nameTr:fmt2.nameEn):'?')
             +(selNiche?' + '+(niche?(S.language==='tr'?niche.nameTr:niche.nameEn):'?'):'');
  setText('cpb-icon',icon);
  setText('cpb-label',selFormat?label:t('create_preview_none'));

  // Button
  setText('btn-create-video',t('create_video_btn'));

  // Done notice
  const dn=el('create-done-notice');
  if(dn){
    if(S.toktik.pendingVideo){
      dn.classList.add('visible');
      dn.textContent=t('create_done_msg');
    } else {
      dn.classList.remove('visible');
    }
  }
}

function queueVideo(){
  if(S.toktik.pendingVideo){showToast(t('create_already'));return;}
  if(!selFormat||!selNiche){showToast(S.language==='tr'?'Format ve niş seç!':'Select a format and niche!');return;}
  if(S.energy<50){SFX.error();showToast(t('create_no_energy'));return;}
  S.energy-=50;
  S.toktik.pendingVideo={format:selFormat,niche:selNiche};
  SFX.success();
  saveState();
  updateEnergyBar();
  renderCreatePanel();
  renderStatsPanel();
  showToast(t('create_done_msg'));
}

/* Leaderboard */
function renderLeaderboard(){
  setText('lb-title',t('lb_title'));
  setText('lb-sub',t('lb_sub'));
  const list=el('lb-list');
  if(!list)return;
  const playerF=S.followers;
  const playerName=S.toktik.username||'You';
  const combined=[...S.aiInfluencers.map(a=>({name:a.name,followers:a.followers,color:a.color,isPlayer:false})),
                  {name:(S.language==='tr'?t('lb_you'):t('lb_you'))+' @'+playerName,followers:playerF,color:'var(--tt-grad)',isPlayer:true}];
  combined.sort((a,b)=>b.followers-a.followers);
  list.innerHTML=combined.map((e,i)=>{
    const rank=i+1;
    const medal=rank===1?'🥇':rank===2?'🥈':rank===3?'🥉':'#'+rank;
    const avaStyle=e.isPlayer?'background:linear-gradient(135deg,var(--cyan),var(--pink));':'background:'+e.color+';';
    return`<div class="lb-row${e.isPlayer?' is-player':''}">
      <span class="lb-rank">${medal}</span>
      <div class="lb-ava" style="${avaStyle}">${e.name[e.isPlayer?2:1]}</div>
      <span class="lb-name">${e.name}</span>
      <span class="lb-f">${fmt(e.followers)}</span>
    </div>`;
  }).join('');
  setTimeout(()=>{
    const pr=list.querySelector('.is-player');
    if(pr)pr.scrollIntoView({block:'nearest',behavior:'smooth'});
  },80);
}

/* Switch TokTik tab */
function switchTTTab(tab){
  document.querySelectorAll('.tt-tab').forEach(b=>b.classList.toggle('active',b.dataset.ttab===tab));
  document.querySelectorAll('.tt-panel').forEach(p=>{
    const active=p.id==='ttp-'+tab;
    p.classList.toggle('active',active);
    p.classList.toggle('hidden',!active);
  });
  SFX.tap();
  if(tab==='stats')renderStatsPanel();
  if(tab==='create')renderCreatePanel();
  if(tab==='board')renderLeaderboard();
}

/* ─────────────────────────────────────────────────────
   SETTINGS
───────────────────────────────────────────────────── */
function renderSettings(){
  setText('settings-title',t('settings_title'));
  setText('stg-hd-audio',t('stg_hd_audio'));
  setText('stg-sound-lbl',t('stg_sound_lbl'));
  setText('stg-hd-lang',t('stg_hd_lang'));
  setText('stg-lang-lbl',t('stg_lang_lbl'));
  setText('stg-hd-privacy',t('stg_hd_privacy'));
  setText('btn-show-privacy',t('btn_show_privacy'));
  setText('stg-hd-data',t('stg_hd_data'));
  setText('btn-save-game',t('btn_save'));
  setText('btn-delete-data',t('btn_delete'));
  const tog=el('sound-toggle');
  if(tog)tog.checked=S.sound;
  const en=el('lpb-en'),tr2=el('lpb-tr');
  if(en)en.classList.toggle('active',S.language==='en');
  if(tr2)tr2.classList.toggle('active',S.language==='tr');
}

/* ─────────────────────────────────────────────────────
   NEXT DAY — Core overnight processing
───────────────────────────────────────────────────── */
function processNextDay(){
  SFX.nextday();

  let views=0, followersGained=0, likesGained=0, adRevenue=0, sponsorBonus=0;
  let isViral=false, hasSynergy=false, newlyMonetized=false;

  // ── Process pending video ──
  if(S.toktik.pendingVideo){
    const {format,niche}=S.toktik.pendingVideo;

    // Base views: 50–300, scaled by algorithm score
    let base=50+Math.floor(Math.random()*250);
    base=Math.floor(base*S.algorithmScore);

    // Synergy bonus
    const syn=SYNERGIES.some(s=>s[0]===format&&s[1]===niche);
    if(syn){base+=150;hasSynergy=true;}

    // Trending 3× multiplier
    const isTrending=S.trendingNiches.includes(niche);
    if(isTrending)base=Math.floor(base*3);

    // Viral chance: 8%
    if(Math.random()<0.08){base=Math.floor(base*(8+Math.random()*12));isViral=true;}

    // Equipment multiplier
    views=Math.floor(base*S.currentEquipmentMultiplier);

    // Follower conversion: 1–5%
    const conv=0.01+Math.random()*0.04;
    followersGained=Math.max(1,Math.floor(views*conv));
    likesGained=Math.max(1,Math.floor(views*0.1));

    S.followers+=followersGained;
    S.likes+=likesGained;
    S.toktik.videos+=1;

    // Algorithm score update
    if(views>500)S.algorithmScore=parseFloat(Math.min(3.0,S.algorithmScore+0.1).toFixed(2));
    else S.algorithmScore=parseFloat(Math.max(0.5,S.algorithmScore-0.05).toFixed(2));

    // Check monetization unlock
    if(S.followers>=10000&&!S.isMonetized){S.isMonetized=true;newlyMonetized=true;}

    // Ad revenue if monetized
    if(S.isMonetized){
      adRevenue=parseFloat(((views/1000)*S.currentBpm).toFixed(2));
      S.cash+=adRevenue;
    }

    // Sponsor daily bonus (local apparel: +200 TL for 3 days)
    if(S.activeSponsor==='local'&&S.sponsorDaysLeft>0){
      sponsorBonus=200;
      S.cash+=200;
      S.sponsorDaysLeft--;
      if(S.sponsorDaysLeft===0)S.activeSponsor=null;
    }

    // Add to feed
    S.toktik.feed=[{format,niche,views,followers:followersGained,day:S.day,isViral,hasSynergy},...(S.toktik.feed||[])].slice(0,12);
    S.toktik.pendingVideo=null;
  }

  // ── Every 5 days: survival cost ──
  let survivalCost=0;
  if(S.day%5===0){survivalCost=10;S.cash-=10;}

  // ── Update AI influencers ──
  tickAI();

  // ── New trends for next day ──
  S.trendingNiches=pickTrending();

  // ── Store report ──
  S.lastReport={
    day:S.day,
    views,
    followersGained,
    likesGained,
    adRevenue,
    sponsorBonus,
    survivalCost,
    newlyMonetized,
    isViral,
    hasSynergy
  };

  // ── Advance day, reset energy ──
  S.day+=1;
  S.energy=MAX_ENERGY;
  S.totalDays=(S.totalDays||0)+1;

  // ── Check cash warning ──
  if(S.cash<0)S.cash=0; // allow going to 0 but not negative for display

  saveState();

  // ── Show morning report (then check sponsors) ──
  showMorningReport();
}

/* ─────────────────────────────────────────────────────
   MORNING REPORT OVERLAY
───────────────────────────────────────────────────── */
function showMorningReport(){
  const r=S.lastReport;
  if(!r){dismissReport();return;}

  const lang=S.language;
  const d=r.day;

  // Choose comment tier
  const tier=r.views>1000?'comments_high':r.views>200?'comments_mid':'comments_low';
  const allComments=t(tier);
  // Pick 3 random
  const picked=[];
  const arr=[...allComments];
  for(let i=0;i<3&&arr.length;i++){
    const idx=Math.floor(Math.random()*arr.length);
    picked.push(arr.splice(idx,1)[0]);
  }

  const commentsHtml=picked.map(([u,c])=>`
    <div class="mr-comment"><span class="mr-cm-user">${u}</span>${c}</div>
  `).join('');

  const viewsVal=r.views>0?fmt(r.views):t('mr_no_video');
  const adRevVal=r.adRevenue>0?'+'+cash(r.adRevenue):'—';
  const survivalHtml=r.survivalCost>0?`
    <div class="mr-survival">${t('mr_survival',{d})}: -${cash(r.survivalCost)}</div>` : '';
  const sponsorHtml=r.sponsorBonus>0?`
    <div class="mr-sponsor-bonus">${t('mr_sponsor_bonus',{n:S.sponsorDaysLeft})}</div>` : '';
  const monetizeHtml=r.newlyMonetized?`
    <div class="mr-monetize-unlock">${t('mr_monetized_unlock')}</div>` : '';
  const viralHtml=r.isViral?`<div style="text-align:center;font-size:20px;margin:6px 0">🔥 VIRAL! 🔥</div>`:'';

  const html=`
    <div class="mr-card">
      <div class="mr-title">${t('mr_title')}</div>
      <div class="mr-day">${t('mr_day',{d})}</div>
      ${viralHtml}
      <div class="mr-stats">
        <div class="mr-stat">
          <span class="mr-stat-lbl">${t('mr_views')}</span>
          <span class="mr-stat-val pos">${viewsVal}</span>
        </div>
        <div class="mr-stat">
          <span class="mr-stat-lbl">${t('mr_followers')}</span>
          <span class="mr-stat-val pos">+${fmt(r.followersGained)}</span>
        </div>
        <div class="mr-stat">
          <span class="mr-stat-lbl">${t('mr_likes')}</span>
          <span class="mr-stat-val pos">+${fmt(r.likesGained)}</span>
        </div>
        <div class="mr-stat">
          <span class="mr-stat-lbl">${t('mr_ad_rev')}</span>
          <span class="mr-stat-val ${r.adRevenue>0?'pos':''}"">${adRevVal}</span>
        </div>
      </div>
      ${monetizeHtml}${sponsorHtml}${survivalHtml}
      <div class="mr-comments-hd">${t('mr_comments_hd')}</div>
      <div class="mr-comments">${r.views>0?commentsHtml:'<div class="mr-comment">No video posted today.</div>'}</div>
      <button class="primary-btn w100" id="btn-dismiss-report">${t('mr_dismiss',{d:S.day})}</button>
    </div>`;

  const overlays=el('phone-overlays');
  if(overlays){
    overlays.classList.add('active');
    overlays.innerHTML=`<div class="p-overlay">${html}</div>`;
    on('btn-dismiss-report','click',dismissReport);
    if(r.isViral)SFX.viral();
  }
}

function dismissReport(){
  const overlays=el('phone-overlays');
  if(overlays){overlays.classList.remove('active');overlays.innerHTML='';}

  updateStatusBar();
  updateEnergyBar();
  renderHome();

  // Check sponsor triggers (after dismissing report)
  setTimeout(checkSponsorTriggers,300);
}

/* ─────────────────────────────────────────────────────
   SPONSOR SYSTEM
───────────────────────────────────────────────────── */
function checkSponsorTriggers(){
  // 50K trigger
  if(S.followers>=50000&&!S.sponsor50kShown&&!S.activeSponsor){
    S.sponsor50kShown=true;
    saveState();
    showSponsorOffer('50k');
    return;
  }
  // 500K trigger
  if(S.followers>=500000&&!S.sponsor500kShown){
    S.sponsor500kShown=true;
    saveState();
    showSponsorOffer('500k');
  }
}

function showSponsorOffer(type){
  const is50k=type==='50k';
  const html=`
    <div class="sp-card">
      <div class="sp-badge">${is50k?'👕':'🏢'}</div>
      <div class="sp-title">${t(is50k?'sp50k_title':'sp500k_title')}</div>
      <div class="sp-body">${t(is50k?'sp50k_body':'sp500k_body')}</div>
      <div class="sp-actions">
        <button class="sp-btn-accept" id="sp-accept">${t(is50k?'sp50k_accept':'sp500k_accept')}</button>
        <button class="sp-btn-decline" id="sp-decline">${t(is50k?'sp50k_decline':'sp500k_decline')}</button>
      </div>
    </div>`;
  const overlays=el('phone-overlays');
  if(!overlays)return;
  overlays.classList.add('active');
  overlays.innerHTML=`<div class="p-overlay">${html}</div>`;
  on('sp-decline','click',()=>{
    SFX.back();
    overlays.classList.remove('active');
    overlays.innerHTML='';
  });
  on('sp-accept','click',()=>{
    if(is50k){
      S.activeSponsor='local';
      S.sponsorDaysLeft=3;
      SFX.success();
      showToast(t('toast_sponsor_accepted'));
    } else {
      // 500k promo: costs 30 energy
      if(S.energy<30){
        SFX.error();
        showToast(t('sp500k_no_energy'));
        return;
      }
      S.energy-=30;
      S.cash+=5000;
      SFX.viral();
      showToast(t('toast_sponsor_recorded'));
      floatReward(S.language==='tr'?'+5.000 TL':'+$5,000',160);
      updateEnergyBar();
    }
    saveState();
    updateStatusBar();
    overlays.classList.remove('active');
    overlays.innerHTML='';
  });
}

/* ─────────────────────────────────────────────────────
   PRIVACY MODAL
───────────────────────────────────────────────────── */
function showPrivacyModal(){
  const html=`
    <div class="privacy-modal-card">
      <div class="pm-title">${t('pm_title')}</div>
      <div class="pm-sub">${t('pm_sub')}</div>
      <div class="pm-scroll">
        <div class="pm-section">
          <div class="pm-section-hd">${t('pm_ds_hd')}</div>
          <div>${t('pm_ds_body')}</div>
        </div>
        <div class="pm-section">
          <div class="pm-section-hd">${t('pm_coppa_hd')}</div>
          <div>${t('pm_coppa_body')}</div>
        </div>
        <div class="pm-section">
          <div class="pm-section-hd">${t('pm_local_hd')}</div>
          <div>${t('pm_local_body')}</div>
        </div>
      </div>
      <button class="pm-close-btn" id="btn-pm-close">${t('pm_close')}</button>
    </div>`;
  const overlays=el('phone-overlays');
  if(!overlays)return;
  overlays.classList.add('active');
  overlays.innerHTML=`<div class="p-overlay">${html}</div>`;
  on('btn-pm-close','click',()=>{
    SFX.back();
    overlays.classList.remove('active');
    overlays.innerHTML='';
  });
}

/* ─────────────────────────────────────────────────────
   DELETE DATA
───────────────────────────────────────────────────── */
function handleDeleteData(){
  if(!confirm(t('delete_confirm')))return;
  if(!confirm(t('delete_confirm2')))return;
  localStorage.clear();
  S=DEF_STATE();
  SFX.error();
  setTimeout(()=>location.reload(),400);
}

/* ─────────────────────────────────────────────────────
   EVENT BINDING
───────────────────────────────────────────────────── */
function bindEvents(){
  // Language overlay
  document.querySelectorAll('.lang-pick-btn').forEach(b=>{
    b.addEventListener('click',()=>{
      SFX.tap();
      S.language=b.dataset.lang;
      el('lang-overlay').classList.add('hidden');
      if(!S.aiInfluencers.length)S.aiInfluencers=generateAI();
      if(!S.trendingNiches.length)S.trendingNiches=pickTrending();
      saveState();
      renderAll();
    });
  });

  // App tiles on home
  document.querySelectorAll('.app-tile').forEach(tile=>{
    tile.addEventListener('click',()=>{
      SFX.open();
      const app=tile.dataset.app;
      if(app==='jobs')showScreen('jobs');
      else if(app==='toktik')showScreen('toktik');
      else if(app==='shop')showScreen('shop');
      else if(app==='settings')showScreen('settings');
    });
  });

  // Back buttons
  document.querySelectorAll('.back-btn').forEach(b=>{
    b.addEventListener('click',()=>{
      SFX.back();
      showScreen(b.dataset.back||'home');
    });
  });

  // Job buttons
  on('btn-flyer','click',()=>{SFX.tap();doJob('flyer');});
  on('btn-moto','click',()=>{SFX.tap();doJob('moto');});

  // TokTik register
  on('tt-register-btn','click',registerTokTik);
  on('tt-username-inp','keydown',e=>{if(e.key==='Enter')registerTokTik();});

  // TokTik tabs
  document.querySelectorAll('.tt-tab').forEach(b=>{
    b.addEventListener('click',()=>switchTTTab(b.dataset.ttab));
  });

  // Create video
  on('btn-create-video','click',()=>{SFX.tap();queueVideo();});

  // Next Day
  on('btn-next-day','click',()=>processNextDay());

  // Settings: sound toggle
  on('sound-toggle','change',e=>{S.sound=e.target.checked;SFX.tap();saveState();});

  // Settings: language pair
  document.querySelectorAll('.lang-pair-btn').forEach(b=>{
    b.addEventListener('click',()=>{
      S.language=b.dataset.lang;
      SFX.tap();
      saveState();
      renderAll();
      showToast(t('toast_lang_changed'));
    });
  });

  // Settings: save
  on('btn-save-game','click',()=>{saveState();SFX.save&&SFX.save();showToast(t('toast_saved'));});

  // Settings: delete data
  on('btn-delete-data','click',handleDeleteData);

  // Settings: privacy
  on('btn-show-privacy','click',()=>{SFX.tap();showPrivacyModal();});

  // Touch prevention
  document.addEventListener('touchstart',()=>{},{ passive:true });
}

// Add save to SFX
SFX.save=()=>{beep(440,.07,'sine',.07);setTimeout(()=>beep(880,.1,'sine',.09),80);};
SFX.open=()=>beep(660,.07,'triangle',.08);

/* ─────────────────────────────────────────────────────
   RENDER ALL (full re-render after language change etc.)
───────────────────────────────────────────────────── */
function renderAll(){
  renderHome();
  updateStatusBar();
  updateEnergyBar();
  setText('btn-next-day',t('next_day_btn'));
  // Update settings lang buttons
  const en=el('lpb-en'),tr2=el('lpb-tr');
  if(en)en.classList.toggle('active',S.language==='en');
  if(tr2)tr2.classList.toggle('active',S.language==='tr');
  // Re-render current screen
  if(currentScreen==='jobs')renderJobs();
  else if(currentScreen==='shop')renderShop();
  else if(currentScreen==='settings')renderSettings();
  else if(currentScreen==='toktik')renderTokTik();
}

/* ─────────────────────────────────────────────────────
   BOOT
───────────────────────────────────────────────────── */
function boot(){
  const hasSave=loadState();

  // Ensure critical arrays
  if(!S.aiInfluencers||!S.aiInfluencers.length)S.aiInfluencers=generateAI();
  if(!S.trendingNiches||!S.trendingNiches.length)S.trendingNiches=pickTrending();

  bindEvents();

  if(hasSave){
    el('lang-overlay').classList.add('hidden');
    showScreen('home');
  } else {
    // Show language selection
    el('lang-overlay').classList.remove('hidden');
    showScreen('home');
  }

  setText('btn-next-day',t('next_day_btn'));
  updateStatusBar();
  updateEnergyBar();
  renderHome();

  // Clock tick
  setInterval(updateStatusBar,30000);
}

if(document.readyState==='loading'){
  document.addEventListener('DOMContentLoaded',boot);
}else{
  boot();
}
